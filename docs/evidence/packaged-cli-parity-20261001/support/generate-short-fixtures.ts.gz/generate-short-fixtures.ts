import { writeFileSync } from 'node:fs';
import { createGame, issueCommand, stepGame } from '../../src/core/simulation';
import { MatchRecorder } from '../../src/core/replays';
import { createSessionFile } from '../../src/core/session-storage';
const output = process.argv[2];
for (const [name, initialTicks, recordedTicks] of [['command-only', 0, 0], ['one-tick', 25, 1]] as const) {
  const state = createGame('orcs', 4127, 'fairies', { mapSize: 'small', controllers: ['external', 'ai'] });
  for (let tick = 0; tick < initialTicks; tick++) stepGame(state, .05);
  const recorder = new MatchRecorder(state);
  const worker = state.entities.find(entity => entity.side === 0 && entity.role === 'worker')!;
  const hq = state.entities.find(entity => entity.side === 0 && entity.role === 'hq')!;
  for (const command of [{ type: 'hold', ids: [worker.id] }, { type: 'train', id: hq.id, role: 'worker' }, { type: 'setRally', ids: [hq.id], x: worker.x, y: worker.y }] as const) {
    if (!issueCommand(state, 0, command)) throw new Error(`${name} rejected ${command.type}.`);
  }
  for (let tick = 0; tick < recordedTicks; tick++) stepGame(state, .05);
  if (!issueCommand(state, 0, { type: 'stop', ids: [worker.id] })) throw new Error(`${name} rejected final same-tick stop.`);
  const archive = recorder.export(); recorder.dispose();
  const file = createSessionFile(state, archive);
  writeFileSync(`${output}/${name}.session.json`, JSON.stringify(file));
  console.log(JSON.stringify({ name, initialTick: archive.initial.state.tick, finalTick: archive.finalTick, commands: archive.actions.filter(action => action.type === 'command').length, checksum: archive.finalChecksum }));
}
