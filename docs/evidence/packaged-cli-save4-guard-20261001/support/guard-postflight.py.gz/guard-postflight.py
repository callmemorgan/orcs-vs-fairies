from pathlib import Path
import gzip,hashlib,json,os,subprocess
base=Path('work/packaged-cli-parity')
output=base/'final-save4-guard-6a634b2-01'
expected='6a634b200bbc978e0bd8abe2e9ba55833190d129'
pre=json.loads((base/'production-and-driver-preflight.json').read_text())
before=json.loads((output/'source-before.json').read_text());after=json.loads((output/'source-after.json').read_text())
assert before==after and before['head']==expected and before['workingTree']==''
assert before['files']==pre['files'] and before['sha256']==pre['sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==expected
assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
depsbefore=json.loads((base/'dependencies-before.json').read_text())
installed=Path('node_modules').resolve();files={};digest=hashlib.sha256()
for item in sorted(installed.rglob('*')):
    name=str(item.relative_to(installed))
    if item.is_symlink():
        target=os.readlink(item);assert item.resolve().is_relative_to(installed)
        data=target.encode();details={'symlink':target}
    elif item.is_file():data=item.read_bytes();details={}
    else:continue
    files[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),**details}
    digest.update(name.encode());digest.update(b'\0');digest.update(data);digest.update(b'\0')
depsafter={'method':depsbefore['method'],'root':str(installed),'sha256':digest.hexdigest(),'files':files}
(base/'dependencies-after.json').write_text(json.dumps(depsafter,indent=2)+'\n')
assert depsbefore==depsafter
buildbefore=json.loads((output/'builds-before.json').read_text());buildafter=json.loads((output/'builds-after.json').read_text());assert buildbefore==buildafter
versions=json.loads((output/'versions.json').read_text());assert versions['save']==4 and versions['simulationRevision']=='4.0.0' and versions['archiveInitialVersion']==4 and versions['archiveRevision']=='4.0.0'
result=json.loads((output/'result.json').read_text());assert result['status']=='passed'
assert result['checks'][0]['ticksChecked']==2402 and result['checks'][0]['commandsChecked']==6 and result['checks'][0]['nativeSessionFinalEqual']
assert result['checks'][1]['checkpointTick']==1201 and [batch['ticks'] for batch in result['checks'][1]['batches']]==[1200,1]
input_bytes=(output/'input.native.json').read_bytes();input_manifest=json.loads((output/'input-manifest.json').read_text())
assert len(input_bytes)==input_manifest['jsonBytes'] and hashlib.sha256(input_bytes).hexdigest()==input_manifest['jsonSha256']
native=json.loads(input_bytes);assert native['game']['version']==4 and native['replay']['initial']['version']==4 and native['replay']['checksumVersion']==4 and native['replay']['simulationRevision']=='4.0.0'
for name in ['main','continuation']:
    status=json.loads((output/f'{name}.process.json').read_text());assert status['code']==0 and not status['signal']
    assert (output/f'{name}.stderr.log').read_bytes()==b''
    with gzip.open(output/f'{name}.stdin.ndjson.gz','rt') as file:requests=sum(1 for line in file)
    with gzip.open(output/f'{name}.stdout.ndjson.gz','rt') as file:
        responses=0;rejected=0
        for line in file:
            response=json.loads(line);responses+=1;rejected+=response['ok'] is False
    assert requests==responses==status['requests'] and rejected==(2 if name=='continuation' else 0)
inputs={}
for name,meta_path in [('productionCLI',output/'dist-cli/metafile.json'),('directCoreReference',output/'reference/metafile.json')]:
    meta=json.loads(meta_path.read_text());rows={};aggregate=hashlib.sha256()
    for meta_name in sorted(meta['inputs']):
        path=Path(meta_name);path=path if path.is_absolute() else Path.cwd()/path
        relative=str(path.relative_to(Path.cwd()))
        data=path.read_bytes();entry={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
        assert entry==pre['files'][relative],relative
        rows[relative]=entry
        aggregate.update(relative.encode());aggregate.update(b'\0');aggregate.update(data);aggregate.update(b'\0')
    inputs[name]={'files':rows,'sha256':aggregate.hexdigest(),'allInputsMatchFrozenGitBytes':True}
(output/'compiled-inputs-against-git.json').write_text(json.dumps({'head':expected,**inputs},indent=2)+'\n')
summary={'status':'passed','head':expected,'allTrackedFilesVerifiedAgainstGit':len(pre['files']),'allTrackedSha256':pre['sha256'],'sourceAndDriverBeforeAfterEqual':True,'productionCLIInputFiles':len(inputs['productionCLI']['files']),'productionCLIInputSha256':inputs['productionCLI']['sha256'],'referenceInputFiles':len(inputs['directCoreReference']['files']),'referenceInputSha256':inputs['directCoreReference']['sha256'],'independentDependencyFiles':len(files),'independentDependenciesBeforeAfterEqual':True,'dependencySha256':depsbefore['sha256'],'compiledPackagesBeforeAfterEqual':True,'currentVersions':versions,'nativeFixtureBytes':len(input_bytes),'nativeFixtureSha256':input_manifest['jsonSha256'],'finalChecksum':result['checks'][0]['finalChecksum'],'finalSha256':result['checks'][0]['finalSha256'],'publicTrafficRequestResponseCountsEqual':True,'processExitsZeroAndStderrEmpty':True,'limitedScope':'Single 2402-tick/six-command generated external+AI session, actual packaged CLI parity and midpoint continuation. No browser-controller arrangement, native victory, full tournament, or later complete-HEAD proof claimed.'}
(output/'guard-audit.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
