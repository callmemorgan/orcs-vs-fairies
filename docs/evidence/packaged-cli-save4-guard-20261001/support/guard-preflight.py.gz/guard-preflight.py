from pathlib import Path
import hashlib,json,os,subprocess
expected='6a634b200bbc978e0bd8abe2e9ba55833190d129'
root=Path.cwd()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==expected
assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
paths=sorted(subprocess.check_output(['git','ls-files','-z'],text=True).split('\0'))
paths=[name for name in paths if name]
files={};digest=hashlib.sha256()
process=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for name in paths:
    data=Path(name).read_bytes()
    process.stdin.write(f'{expected}:{name}\n'.encode());process.stdin.flush()
    header=process.stdout.readline().decode().strip().split(' ')
    assert len(header)==3 and header[1]=='blob',(name,header)
    size=int(header[2]);stored=process.stdout.read(size)
    assert process.stdout.read(1)==b'\n'
    assert data==stored,name
    files[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
    digest.update(name.encode());digest.update(b'\0');digest.update(data);digest.update(b'\0')
process.stdin.close();assert process.wait()==0
result={'head':expected,'workingTree':'','sha256':digest.hexdigest(),'files':files,'allBytesMatchPinnedGitBlobs':True}
Path('work/packaged-cli-parity/production-and-driver-preflight.json').write_text(json.dumps(result,indent=2)+'\n')
installed=Path('node_modules').resolve();upstream=Path('/home/morgana/Projects/orcs-vs-Fairies/node_modules').resolve()
depfiles={};depdigest=hashlib.sha256()
for item in sorted(installed.rglob('*')):
    relative=str(item.relative_to(installed))
    if item.is_symlink():
        target=os.readlink(item)
        assert item.resolve().is_relative_to(installed),(item,target)
        data=target.encode();details={'symlink':target}
    elif item.is_file():
        data=item.read_bytes();details={}
        original=upstream/relative
        if original.exists():assert (original.stat().st_dev,original.stat().st_ino)!=(item.stat().st_dev,item.stat().st_ino),relative
    else:continue
    depfiles[relative]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),**details}
    depdigest.update(relative.encode());depdigest.update(b'\0');depdigest.update(data);depdigest.update(b'\0')
deps={'method':'Independent copy of installed dependency tree, with separate file inodes and all symlinks resolving inside the copied tree. No shared root/dependency writes.','root':str(installed),'sha256':depdigest.hexdigest(),'files':depfiles}
Path('work/packaged-cli-parity/dependencies-before.json').write_text(json.dumps(deps,indent=2)+'\n')
print(json.dumps({'pin':expected,'allTrackedFilesMatchGit':len(files),'allSourceSha256':result['sha256'],'independentDependencyFiles':len(depfiles),'dependencySha256':deps['sha256']}))
