import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { readFile, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { createInterface } from 'node:readline';
import { createGunzip } from 'node:zlib';
const output=resolve(process.argv[2]), sha256=text=>createHash('sha256').update(text).digest('hex');
const comparisons=JSON.parse(await readFile(join(output,'comparisons.json'),'utf8')), input=JSON.parse(await readFile(join(output,'input.native.json'),'utf8')), checks=[];
function checksum(text){let hash=2166136261;for(let i=0;i<text.length;i++){hash^=text.charCodeAt(i);hash=Math.imul(hash,16777619);}return(hash>>>0).toString(16).padStart(8,'0');}
for(const name of ['main','continuation']){
 const expected=comparisons.filter(value=>value.process===name), status=JSON.parse(await readFile(join(output,`${name}.process.json`),'utf8')), saves=[];
 const stdout=createInterface({input:createReadStream(join(output,`${name}.stdout.ndjson.gz`)).pipe(createGunzip()),crlfDelay:Infinity});
 let responses=0,rejected=0;
 for await(const line of stdout){
  responses++;const response=JSON.parse(line);if(!response.ok){rejected++;continue;}if(response.result?.format!=='orcs-vs-fairies-save')continue;
  const save=response.result,text=JSON.stringify(save), comparison=expected[saves.length];assert(comparison);
  assert.equal(save.state.tick,comparison.tick);assert.equal(sha256(text),comparison.sha256);assert.equal(comparison.coreSha256,comparison.sha256);
  assert.equal(checksum(text),comparison.checksum);assert.equal(comparison.coreChecksum,comparison.checksum);assert.equal(Buffer.byteLength(text),comparison.bytes);
  save.state.visible=save.state.visible.map(cells=>cells.sort((a,b)=>a-b));save.state.explored=save.state.explored.map(cells=>cells.sort((a,b)=>a-b));
  saves.push({nativeSha256:comparison.sha256,cliLogSha256:sha256(JSON.stringify(save))});
 }
 assert.equal(saves.length,expected.length);assert.equal(responses,status.requests);assert.equal(rejected,name==='continuation'?2:0);
 const log=createInterface({input:createReadStream(join(output,`${name}.cli-log.ndjson`)),crlfDelay:Infinity});let logged=0,loggedSaves=0;
 for await(const line of log){logged++;const entry=JSON.parse(line);if(entry.input.op==='save'){assert.equal(entry.hash,saves[loggedSaves]?.cliLogSha256);loggedSaves++;}}
 assert.equal(loggedSaves,saves.length);assert.equal(logged,status.requests-rejected);
 const final=JSON.parse(await readFile(join(output,`${name}.final.cli-save.json`),'utf8'));assert.equal(sha256(JSON.stringify(final)),saves.at(-1).nativeSha256);assert.equal(JSON.stringify(final),JSON.stringify(input.game));
 checks.push({process:name,publicRequests:status.requests,nativeSavesMatchedToComparisons:saves.length,cliHashLogEntries:logged,protocolErrors:rejected,completeNativeFinalSessionEqual:true});
}
const result={status:'passed',sourcePin:'6a634b200bbc978e0bd8abe2e9ba55833190d129',method:'Audit retained stdout only: recompute every complete native-save SHA-256 and UTF-16 FNV checksum, compare with direct-core records and public CLI hash log, then compare both complete final saves with the retained native session game. No second simulation or CLI proof run.',checks};
await writeFile(join(output,'protocol-audit.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
